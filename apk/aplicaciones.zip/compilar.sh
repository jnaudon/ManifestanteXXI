#!/bin/sh

zip -9 aplicaciones.zip *
